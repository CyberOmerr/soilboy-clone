import React from 'react';
import './FeaturedProducts.css';

const FeaturedProducts = () => {
  const products = [
    {
      id: 1,
      name: 'Cascading Hawthorn Bonsai (Japan)',
      price: 'from SGD 108.00',
      isSoldOut: true,
      image: require('../assets/hawtorn-gy-bonsai.jpg')
    },
    {
      id: 2,
      name: 'Bending Manuka Myrtle (Japan)',
      price: 'from SGD 108.00',
      isSoldOut: false,
      image: require('../assets/manuka-moon-myrtle.jpg')
    },
    {
      id: 3,
      name: 'Isozansho Bonsai',
      price: 'from SGD 158.00',
      isSoldOut: false,
      image: require('../assets/bonsai 2.jpg')
    }
  ];

  return (
    <section className="featured-products">
      <div className="container">
        <header className="section-header">
          <h3 className="section-title">Featured Products</h3>
          <a href="#" className="view-all">View All</a>
        </header>
        
        <div className="products-grid">
          {products.map(product => (
            <div key={product.id} className="product-card">
              <div className="product-image">
                <img src={product.image} alt={product.name} />
                {product.isSoldOut && <span className="sold-out-label">sold out</span>}
              </div>
              <div className="product-info">
                <h4 className="product-name">{product.name}</h4>
                <p className="product-price">{product.price}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturedProducts; 
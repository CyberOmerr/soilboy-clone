import React from 'react';
import './SocialFeed.css';

const SocialFeed = () => {
  const images = [
    { src: '/images/insta1.jpeg', alt: 'Plant' },
    { src: '/images/insta2.jpeg', alt: 'Soil' },
    { src: '/images/insta3.jpeg', alt: 'Ceramic pot' },
    { src: '/images/insta4.jpeg', alt: 'Pebbles' }
  ];

  return (
    <section className="social-feed">
      <div className="container">
        <div className="social-grid">
          {images.map((image, index) => (
            <div key={index} className="social-item">
              <img src={image.src} alt={image.alt} />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default SocialFeed; 
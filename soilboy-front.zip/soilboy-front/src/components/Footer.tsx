import React from 'react';
import './Footer.css';

const Footer = () => {
  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-content">
          <div className="footer-section newsletter-section">
            <h4 className="footer-title">Stay Updated</h4>
            <p className="newsletter-text">Sign up with your email address to receive news and updates.</p>
            
            <div className="newsletter-form">
              <input type="email" placeholder="Email Address" className="newsletter-input" />
              <button className="newsletter-btn">Sign Up</button>
            </div>
          </div>

          <div className="footer-section">
            <h4 className="footer-title">Info</h4>
            <ul className="footer-links">
              <li><a href="#">About</a></li>
              <li><a href="#">Plant Care</a></li>
            </ul>
          </div>
          
          <div className="footer-section">
            <h4 className="footer-title">Follow</h4>
            <ul className="footer-links">
              <li><a href="#">Facebook</a></li>
              <li><a href="#">Instagram</a></li>
            </ul>
          </div>
          
          <div className="footer-section">
            <h4 className="footer-title">Contact</h4>
            <address className="footer-address">
              46 Kim Yam Road<br />
              #02-07/8, S239351<br /><br />
              hello@soilboy.sg
            </address>
          </div>
        </div>
        
        <div className="footer-bottom">
          <div className="footer-policies">
            <a href="#">FAQs and Delivery</a>
            <a href="#">Privacy Policy</a>
          </div>
          <div className="footer-copyright">
            Soilboy © 2025
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer; 
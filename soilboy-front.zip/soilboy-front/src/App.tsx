import React from 'react';
import './App.css';
import Header from './components/Header';
import Hero from './components/Hero';
import FeaturedProducts from './components/FeaturedProducts';
import TorchinLamp from './components/TorchinLamp';
import FeaturedProduct from './components/FeaturedProduct';
import Collections from './components/Collections';
import SoilMix from './components/SoilMix';
import PlantCare from './components/PlantCare';
import Mission from './components/Mission';
import SocialFeed from './components/SocialFeed';
import Footer from './components/Footer';


function App() {
  return (
    <div className="App">
      <Header />
      <main>
        <Hero />
        <FeaturedProducts />
        <TorchinLamp />
        <FeaturedProduct 
          title="Introducing Soilboy Pebbles in different Colours"
          description="Crafted with Handcrafted by Gaonyou Ceramics - South Korea&#10;Limited quantities available."
          imageUrl="/images/soilboy-pebbles.jpg" 
          buttonText="Shop Now"
        />
        <Collections />
        <SoilMix />
        <PlantCare />
        <Mission />
        <SocialFeed />
        <div className="follow-us">
          <p>Follow us <a href="https://instagram.com/soilboy">@soilboy</a></p>
        </div>
      </main>
      <Footer />
    </div>
  );
}

export default App; 
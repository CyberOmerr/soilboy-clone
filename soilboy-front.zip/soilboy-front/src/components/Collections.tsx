import React from 'react';
import './Collections.css';

const Collections = () => {
  return (
    <section className="collections">
      <div className="collection-container">
        <div className="collection-content">
          <h2 className="collection-title">Shop our collection of ceramics planters</h2>
          <button className="collection-btn">Shop now</button>
        </div>
        <div className="collection-image">
          <img 
            src="/images/ceramic.jpg" 
            alt="Ceramics planters" 
          />
        </div>
      </div>
    </section>
  );
};

export default Collections; 
import React from 'react';
import './FeaturedProduct.css';

interface FeaturedProductProps {
  title?: string;
  description?: string;
  imageUrl?: string;
  buttonText?: string;
}

const FeaturedProduct: React.FC<FeaturedProductProps> = ({
  title = "Introducing Soilboy Pebbles in different Colours",
  description = "Crafted with Handcrafted by Gaonyou Ceramics - South Korea\nLimited quantities available.",
  imageUrl = "/images/pebbles.jpg",
  buttonText = "Shop Now"
}) => {
  return (
    <section className="featured-product-section">
      <div className="featured-product-container">
        <div className="featured-product-image-container">
          <img src={imageUrl} alt={title} className="featured-product-image" />
        </div>
        <div className="featured-product-info">
          <div className="featured-product-text">
            <h2 className="featured-product-title">{title}</h2>
            <p className="featured-product-description">{description}</p>
          </div>
          <button className="featured-product-button">{buttonText}</button>
        </div>
      </div>
    </section>
  );
};

export default FeaturedProduct; 
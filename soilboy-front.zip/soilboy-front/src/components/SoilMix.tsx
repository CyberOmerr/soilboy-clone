import React from 'react';
import './SoilMix.css';

const SoilMix = () => {
  return (
    <section className="soil-mix">
      <div className="soil-mix-container">
        <div className="soil-mix-image">
          <img src="/images/soil.jpg" alt="Soil mix in a metal scoop" />
        </div>
        <div className="soil-mix-content">
          <h2>Ready-to-use soil mix<br />now available</h2>
          <a href="/shop" className="shop-now-btn">Shop now</a>
        </div>
      </div>
    </section>
  );
};

export default SoilMix; 
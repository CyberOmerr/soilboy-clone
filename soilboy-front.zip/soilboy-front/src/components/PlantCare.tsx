import React from 'react';
import './PlantCare.css';

const PlantCare = () => {
  return (
    <section className="plant-care">
      <div className="plant-care-container">
        <div className="plant-care-text">
          <h2>Unlike humans, plants don't need to be watered everyday.</h2>
          <a href="#" className="learn-more">Learn More</a>
        </div>
        <div className="plant-care-image">
          <img src="/images/plant.jpg" alt="Olive plant with thin leaves" />
        </div>
      </div>
    </section>
  );
};

export default PlantCare; 
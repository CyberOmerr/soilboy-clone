import React from 'react';
import './TorchinLamp.css';

const TorchinLamp = () => {
  return (
    <section className="torchin-lamp">
      <div className="container">
        <div className="torchin-content">
          <h2 className="torchin-title">Torchin Lamp - handcrafted in Japan</h2>
          <a href="#" className="btn torchin-btn">Shop now</a>
        </div>
      </div>
    </section>
  );
};

export default TorchinLamp; 
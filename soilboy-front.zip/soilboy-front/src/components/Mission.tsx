import React from 'react';
import './Mission.css';

const Mission = () => {
  return (
    <section className="mission">
      <div className="container">
        <div className="mission-content">
          <h4 className="mission-text">
            We're here for a mission, and one mission only: to inspire a sense of curiosity for the greener things in life. 'Cause at SoilBoy, we do it right.
          </h4>
          <a href="#" className="mission-link">Find out more</a>
        </div>
      </div>
    </section>
  );
};

export default Mission; 
import React, { useState, useEffect } from 'react';
import './Header.css';

const Header = () => {
  const [isPlantsHovered, setIsPlantsHovered] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const scrollPosition = window.scrollY;
      setIsScrolled(scrollPosition > 50);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className={`header ${isScrolled ? 'scrolled' : ''}`}>
      <div className="skip-content">Skip to Content</div>
      
      <div className="header-container">
        <nav className="main-nav">
          <ul className="nav-list">
            <li 
              className="nav-item plants-item"
              onMouseEnter={() => setIsPlantsHovered(true)}
              onMouseLeave={() => setIsPlantsHovered(false)}
            >
              <a href="#">Plants</a>
              {isPlantsHovered && (
                <div className="dropdown-menu">
                  <a href="#">Potted Plants</a>
                  <a href="#">Planters</a>
                  <a href="#">Essentials</a>
                </div>
              )}
            </li>
            <li className="nav-item"><a href="#">Workshops</a></li>
            <li className="nav-item"><a href="#">Lifestyle</a></li>
          </ul>
        </nav>
        
        <div className="logo">
          <a href="#">Soilboy</a>
        </div>
        
        <div className="header-actions">
          <a href="#" className="login-link">Login Account</a>
          <a href="#" className="cart-link">0</a>
          <a href="#" className="contact-link">Contact us</a>
        </div>
      </div>
    </header>
  );
};

export default Header; 